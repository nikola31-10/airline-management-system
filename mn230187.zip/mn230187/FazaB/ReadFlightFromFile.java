package FazaB;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReadFlightFromFile {

	private String filename;
	private AirportMap owner;
	public ReadFlightFromFile(String filename,AirportMap owner) {
		this.filename=filename;
		this.owner=owner;
	}
	public void ucitaj() {
		
		try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            int redniBroj=1;
            while ((line = br.readLine()) != null) {
            	String[] delovi = line.split(",");
            	if (delovi.length < 4) {
	                Dialogs.showError(owner, 
	                    "Linija " + redniBroj + " nema dovoljno delova: " + line);
	                redniBroj++;
	                continue; // preskoci ovu liniju i nastavi sa sledecom
	            }
            	owner.dugmeFl(delovi[0], delovi[1], delovi[2],delovi[3]);
            	redniBroj++;
            	
            	
            }
        } catch (IOException e) {
            //e.printStackTrace();
        	Dialogs.showError(owner, "Nepostojeci fajl");
        }
	}
}
