package FazaB;


import java.awt.Label;

public class Timer extends Thread {

	private boolean  started=false;
    private Label label;
    private int secondsPassed = 0;
    private int maxSeconds = 60; // пример: 30 секунди
    private boolean active = true;   // преименовано из running
    private boolean running = true;  // преименовано из paused
    private Scene scene;
    private AirportMap mapa;

    public Timer(Label label, Scene scene, AirportMap mapa) {
        this.label = label;
        this.scene = scene;
        this.mapa = mapa;
    }
    @Override
    public void start() {
        if (!started) {
            started = true;
            super.start();
        } else {
            System.out.println("Nit je već startovana!");
        }
    }

    @Override
    public void run() {
        try {
            while (active && secondsPassed < maxSeconds) {
                synchronized (this) {
                    while (!running) { // ako nije running onda pauza
                        wait();
                    }
                }

                Thread.sleep(1000); // ceka 1 sekundu
                secondsPassed++;

                
                if (this.getSecondsPassed() == 55) {
                    //Dialogs.showError(this.mapa, "ovo je vreme");
                	Dialogs.showOption(mapa, "Da li zelite da nastavite sa radom",this);
                    if(this.getSecondsPassed() == 60) {
                    	stopTimer();
                    }
                }

                label.setText("Time: " + secondsPassed);
                this.scene.repaint();
            }
        } catch (InterruptedException e) {
            
        }

        if (secondsPassed >= maxSeconds) {
            //System.out.println("Program shutting down...");
            //System.exit(0);
        }
    }

    // STOP
    public void stopTimer() {
        active = false;
        this.interrupt();
        this.mapa.dispose();
        scene.blinkTimer.stopTimer();
        mapa.sceneWindow.dispose();
        //this.scene.dispose();
    }

    // PAUSE
    public synchronized void pauseTimer() {
        running = false;
    }

    // RESUME
    public synchronized void resumeTimer() {
        running = true;
        notify(); // probudi 
    }

    // RESET
    public synchronized void resetSecondsPassed() {
        secondsPassed = 0;
        label.setText("Time: 0");
    }

    public int getSecondsPassed() {
        return secondsPassed;
    }
    public boolean isActive() {
    	return active;
    }
    public boolean isPaused() {
    	return !running;
    }
    public boolean isStarted() {
    	return started;
    }
}
