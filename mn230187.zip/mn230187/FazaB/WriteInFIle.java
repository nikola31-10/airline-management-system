package FazaB;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;

public class WriteInFIle {

    // metoda koja prima ime fajla i tekst koji se upisuje
    public static void upisiUFajl(String filename, String tekst) {
        try (FileWriter fw = new FileWriter(filename, false);  // true = dopisivanje
             PrintWriter pw = new PrintWriter(fw)) {

            pw.println(tekst);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
