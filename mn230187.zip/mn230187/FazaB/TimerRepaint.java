package FazaB;

import java.awt.Label;

public class TimerRepaint extends Thread {

    private int secondsPassed = 0;
    private int maxSeconds = 10000; // maksimalni broj koraka
    private boolean running = true;  // kontrola pauze
    private boolean active = true;   // kontrola zavrsetka niti
    private Scene scene;
    private boolean started=false;

    public TimerRepaint(Scene scene) {
        this.scene = scene;
    }
    @Override
    public void start() {
        if (!started) {
            started = true;
            super.start();
        } else {
            System.out.println("Nit je već startovana!");
        }
    }

    @Override
    public void run() {
        try {
            while (active && secondsPassed < maxSeconds) {
                synchronized(this) {
                    while (!running) { // ako je pauza, ceka
                        wait();
                    }
                }

                Thread.sleep(200); // repaint na svakih 200ms
                secondsPassed++;

                // repaint na canvasu
                scene.repaint();
            }
        } catch (InterruptedException e) {
            // nit je prekinuta ili pauzirana
        }
    }

    // Pauziranje niti
    public synchronized void pauseTimer() {
        running = false;
    }

    // Nastavak niti
    public synchronized void resumeTimer() {
        running = true;
        notify(); // probudi nit iz wait()
    }

    // Potpuno zaustavljanje niti
    public synchronized void stopTimer() {
        active = false;
        running = false;
        this.interrupt();
    }

    // Reset broja sekundi/koraka
    public synchronized void resetSecondsPassed() {
        this.secondsPassed = 0;
    }

    public int getSecondsPassed() {
        return secondsPassed;
    }
    public boolean isPaused() {
    	return !running;
    	
    }
    public boolean isStarted() {
    	return started;
    }
}
