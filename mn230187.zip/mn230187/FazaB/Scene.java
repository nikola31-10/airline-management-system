package FazaB;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Scene extends Canvas {
    private int rows = 200;
    private int cellSize = 3;
    private AirportMap owner;
    private boolean simulation = false;
    TimerBlink blinkTimer;
    private int maxArrival=0;

    private Image gridImage; // mreža koja se crta samo jednom

    public Scene(AirportMap owner) {
    	
        this.owner = owner;
        setSize(rows * cellSize, rows * cellSize);
        //this.sceneWindow=sceneWindow;
        blinkTimer = new TimerBlink(this);
        blinkTimer.start();

        // mouse listener
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                for (Airport elem : owner.getAirports()) {
                    int maprX = mapX(elem.getX());
                    int maprY = mapY(elem.getY());

                    if (maprX <= e.getX() && e.getX() <= maprX + cellSize &&
                        maprY <= e.getY() && e.getY() <= maprY + cellSize) {
                        elem.setBlink(!elem.isBlink());
                    } else {
                        elem.setBlink(false);
                    }
                }
                repaint();
            }
        });
        /*addMouseMotionListener(new MouseAdapter() {
            @Override
            public void mouseMoved(MouseEvent e) {
                for (Airport elem : owner.airports) {
                    int maprX = mapX(elem.getX());
                    int maprY = mapY(elem.getY());

                    if (maprX <= e.getX() && e.getX() <= maprX + cellSize &&
                        maprY <= e.getY() && e.getY() <= maprY + cellSize) {
                        elem.enter=true;
                    } else {
                        elem.enter=false;
                    }
                }
                repaint();
            }
        });*/
    }

    // Kreira mrežu tek kada Canvas bude realizovan
    @Override
    public void addNotify() {
        super.addNotify();
        if (gridImage == null) {
            createGridImage();
        }
    }

    private void createGridImage() {
        int size = rows * cellSize;
        gridImage = createImage(size, size);
        if (gridImage == null) return; // zaštita
        Graphics g = gridImage.getGraphics();
        g.setColor(Color.LIGHT_GRAY);

        // horizontalne linije
        for (int i = 0; i <= rows; i++) {
            g.drawLine(0, i * cellSize, size, i * cellSize);
        }
        // vertikalne linije
        for (int i = 0; i <= rows; i++) {
            g.drawLine(i * cellSize, 0, i * cellSize, size);
        }
        
        /*g.setColor(Color.BLACK);
        g.drawLine(mapX(0), mapY(90),mapX(0) , mapY(-90));
        g.drawLine(mapX(-90), mapY(0),mapX(90) , mapY(0));
        for(int j=0;j<=90;j++) {
        	if(j/5*5==j) {
        	g.setFont(new Font("Arial", Font.BOLD, 7));
        	g.drawString(""+j, mapX(0+3), mapY(j));}
        }*/
        g.dispose();
    }

    private int mapX(int x) {
        return (x + 90) * cellSize;
    }

    private int mapY(int y) {
        return Math.abs(y - 90) * cellSize;
    }

    @Override
    public void paint(Graphics g) {
        // crtanje mreze iz slike
        if (gridImage != null) {
            g.drawImage(gridImage, 0, 0, this);
            //drawGrid(g);
        }

        if(isThereMark() && !simulation) {
        	owner.getTimer().pauseTimer();
        }
        else if(!simulation) {
        	owner.getTimer().resumeTimer();
        }
        g.setColor(Color.GRAY);
        boolean uso=false;
        for (Airport elem : owner.getAirports()) {
            if (owner.getMapa().get(elem.getName()).getState()) {
                int xkor = mapX(elem.getX());
                int ykor = mapY(elem.getY());

                if (elem.isBlink()) {
                    g.setColor(blinkTimer.getRed() ? Color.RED : Color.GRAY);
                } else {
                    g.setColor(Color.GRAY);
                }
                /*if(elem.enter) {
                	g.setFont(new Font("Arial", Font.BOLD, 30));
                	g.drawString("mranjao", xkor, ykor+20);
                }*/

                g.fillRect(xkor, ykor, cellSize, cellSize);
                g.setColor(Color.BLACK);
                g.setFont(new Font("Arial", Font.BOLD, 7));
                g.drawString(elem.getName(), xkor, ykor+10); 
                g.setColor(Color.GRAY);

                if (simulation) {
                    g.setColor(Color.BLUE);
                    
                    for (Flight let : elem.getFlights()) {
                    	if(maxArrival<let.getArrivalTime()) {
                    		maxArrival=let.getArrivalTime();
                    	}
                    	uso=true;
                    	String[] parts = let.getFlight_time().split(":");
                    	int sati = Integer.parseInt(parts[0]);   // 12
                    	int minuti = Integer.parseInt(parts[1]); // 34
                        int t = owner.getTimerSim().getSecondsPassed();
                        //int start = Integer.parseInt(let.getFlight_time()[]);
                        //double procenat = Math.min(s / distance, 1.0); // da ne pređe cilj s formula distance distanca
                        int start=sati*60+minuti;
                        int trajanje = let.getFlight_duration();
                        int kraj = start + trajanje;

                        if (t >= start && t <= kraj) {
                            double procenat = (t - start) / (double) trajanje;
                            int xx = (int) (let.getStart_x() + (let.getEnd_x() - let.getStart_x()) * procenat);
                            int yy = (int) (let.getStart_y() + (let.getEnd_y() - let.getStart_y()) * procenat);
                            g.fillOval(mapX(xx), mapY(yy), cellSize, cellSize);
                        }
                        if(maxArrival<=owner.getTimerSim().getSecondsPassed()) {
                        
                        	owner.getTimerSim().pauseTimer();
                        	try {
								owner.getTimerSim().sleep(1000);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
                        	owner.getTimerSim().resetSecondsPassed();
                        	//owner.getTimerSim().resetSecondsPassed();
                        	simulation=false;
                        	maxArrival=0;
                        	owner.getTimer().resumeTimer();
                        }
                    }
                    
                    g.setColor(Color.GRAY);
                }
            }
            else {
            	elem.setBlink(false);
            }
        }
        if(!uso && simulation) {
        	simulation=false;
        	
        	owner.getTimerSim().pauseTimer();
        	//owner.getTimerSim().resetSecondsPassed();
        	owner.getTimerSim().resetSecondsPassed();
        	owner.getTimerRepaint().pauseTimer();
        	simulation=false;
        	maxArrival=0;
        	owner.getTimer().resumeTimer();
        	
        }
    }
    private boolean isThereMark() {
    	for (Airport elem : owner.getAirports()) {
    		if(elem.isBlink()) {
    			return true;
    		}
    	}
    	return false;
    }
    private void drawGrid(Graphics g) {
        g.setColor(Color.LIGHT_GRAY);
        int size = rows * cellSize;

        // horizontalne linije
        for (int i = 0; i <= rows; i++) {
            g.drawLine(0, i * cellSize, size, i * cellSize);
        }

        // vertikalne linije
        for (int i = 0; i <= rows; i++) {
            g.drawLine(i * cellSize, 0, i * cellSize, size);
        }
    }
    public boolean getSimulation() {
    	return this.simulation;
    }
    public void setSimulation(boolean bul) {
    	 this.simulation=bul;
    }
    
}
