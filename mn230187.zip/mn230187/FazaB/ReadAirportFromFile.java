package FazaB;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReadAirportFromFile {

	private String filename;
	private AirportMap owner;
	public ReadAirportFromFile(String filename,AirportMap owner) {
		this.filename=filename;
		this.owner=owner;
	}
	public void ucitaj() {
	    try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
	        String line;
	        int redniBroj = 1; // da znamo koji red je los
	        while ((line = br.readLine()) != null) {
	            String[] delovi = line.split(",");
	            
	            if (delovi.length < 3) {
	                Dialogs.showError(owner, 
	                    "Linija " + redniBroj + " nema dovoljno delova: " + line);
	                redniBroj++;
	                continue; // preskoci ovu liniju i nastavi sa sledecom
	            }
	            
	            owner.dugmeZaDodavanjeAirport(delovi[0], delovi[1], delovi[2]);
	            redniBroj++;
	        }
	    } catch (IOException e) {
	        Dialogs.showError(owner, "Nepostojeci fajl: " + filename);
	    }
	}

}
