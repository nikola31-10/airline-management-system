package FazaB;

import java.util.ArrayList;
import java.util.List;

public class Airport {
	private int x;
	private int y;
	private String name;
	private List<Flight> flights=new ArrayList<>();
	private boolean blink=false;
	private boolean blinkState=false;
	public boolean enter=false;

	public List<Flight> getFlights() {
		return flights;
	}



	public void setFlights(List<Flight> flights) {
		this.flights = flights;
	}



	public boolean isBlinkState() {
		return blinkState;
	}



	public void setBlinkState() {
		this.blinkState = !this.blinkState;
	}



	public boolean isBlink() {
		return blink;
	}



	public void setBlink(boolean blink) {
		this.blink = blink;
	}



	public int getX() {
		return x;
	}



	public void setX(int x) {
		this.x = x;
	}



	public int getY() {
		return y;
	}



	public void setY(int y) {
		this.y = y;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}

	public Airport(int x, int y, String name) {
		//super();
		this.x = x;
		this.y = y;
		this.name = name;
	}



}
