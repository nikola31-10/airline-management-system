package FazaB;
import java.awt.*;

public class SceneWindow extends Frame {
    private Scene scene;

    public SceneWindow(AirportMap owner) {
        setTitle("Scena");
        //scene.sceneWindow=this;
        scene = owner.scene;
        scene.setPreferredSize(new Dimension(180 * 5, 180 * 5)); // 180x180 ćelija * 5 px
        add(scene);

        pack(); // postavi dimenzije prema preferred size
        Insets insets = getInsets(); // margine prozora (naslovna traka, obrubi)
        int width = scene.getWidth() + insets.left + insets.right;
        int height = scene.getHeight() + insets.top + insets.bottom;
        //setSize(width, height);
        setSize(650,650);

        setResizable(false);
        setLocation(50, 50);
        setVisible(true);
    

        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent e) {
            	owner.stopTimers();
            	//scene.blinkTimer.stopTimer();
            	owner.dispose();
                dispose();
            }
        });
    }

    public Scene getScene() {
        return scene;
    }

    
}