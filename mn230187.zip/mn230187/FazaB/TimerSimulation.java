package FazaB;

import java.awt.Label;

public class TimerSimulation extends Thread {

    private Label label;
    private int secondsPassed = 0;
    private int maxSeconds = 10000; // program se gasi nakon 10000 koraka
    private boolean running = true; // kontrola pauze
    private boolean active = true;  // kontrola kada nit treba da zavrsi
    private Scene scene;
    private boolean started=false;

    public TimerSimulation(Label label, Scene scene) {
        this.label = label;
        this.scene = scene;
    }
    @Override
    public void start() {
        if (!started) {
            started = true;
            super.start();
        } else {
            System.out.println("Nit je već startovana!");
        }
    }

    @Override
    public void run() {
        try {
            while (active && secondsPassed < maxSeconds) {
                synchronized(this) {
                    while (!running) { // ako je pauza, ceka
                        wait();
                    }
                }

                Thread.sleep(100); // cekaj 100ms
                secondsPassed++;
                String withdoth = form(secondsPassed);
                label.setText("TimeSim: " + withdoth);
                // scene.repaint(); // opcionalno, ako zelis da osvezis scenu
            }
        } catch (InterruptedException e) {
            // nit je prekinuta ili pauzirana
        }
    }

    // Pauziranje tajmera
    public synchronized void pauseTimer() {
        running = false;
    }

    // Nastavak tajmera
    public synchronized void continueTimer() {
        running = true;
        notify(); // budi nit iz wait()
    }

    // Potpuno zaustavljanje niti
    public synchronized void stopTimer() {
        active = false;
        running = false;
        this.interrupt();
    }

    // Reset tajmera
    public synchronized void resetSecondsPassed() {
        this.secondsPassed = 0;
        label.setText("TimeSim: 00:00");
    }

    public int getSecondsPassed() {
        return secondsPassed;
    }

    // Pretvaranje broja sekundi u format mm:ss
    private String form(int number) {
        int min = number / 60;
        int sec = number % 60;
        return String.format("%02d:%02d", min, sec);
    }
    public boolean isPaused() {
    	return !running;
    	
    }
    public boolean isStarted() {
    	return started;
    }
}
