package FazaB;

public class TimerBlink extends Thread {
    private Scene scene;
    private boolean red = false;
    private boolean running = true;
    private boolean started = false;

    public TimerBlink(Scene scene) {
        this.scene = scene;
    }
    @Override
    public void start() {
        if (!started) {
            started = true;
            super.start();
        } else {
            System.out.println("Nit je već startovana!");
        }
    }

    @Override
    public void run() {
        try {
            while (running) {
                Thread.sleep(500); // menja boju svakih 0.5s
                red = !red;
                scene.repaint();   // osvezi ekran
            }
        } catch (InterruptedException e) {
            // nit prekinuta
        }
    }

    public boolean getRed() {
        return red;
    }

    public void stopTimer() {
        running = false;
        this.interrupt();
    }
}
