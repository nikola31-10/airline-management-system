package FazaB;

public class Flight {

	private String start_Airport;
	private String end_Airport;
	private String flight_time;
	private int arrival_time=0;
	private String new_flight_time;
	private int flight_duration;
	private boolean go;
	private int start_x;
	private int start_y;
	private int end_x;
	private int end_y;
	private AirportMap owner;
	
	public Flight(String start_Airport, String end_Airport, String flight_time, int flight_duration,AirportMap owner) {
		this.start_Airport = start_Airport;
		this.end_Airport = end_Airport;
		this.flight_time = flight_time;
		this.flight_duration = flight_duration;
		this.new_flight_time=flight_time;
		this.go=false;
		this.owner=owner;
		setCords();
		
	}
	public String getStart_Airport() {
		return start_Airport;
	}
	public void setStart_Airport(String start_Airport) {
		this.start_Airport = start_Airport;
	}
	public String getEnd_Airport() {
		return end_Airport;
	}
	public void setEnd_Airport(String end_Airport) {
		this.end_Airport = end_Airport;
	}
	public String getFlight_time() {
		return flight_time;
	}
	public void setFlight_time(String flight_time) {
		this.flight_time = flight_time;
	}
	public String getNew_flight_time() {
		return new_flight_time;
	}
	public void setNew_flight_time(String new_flight_time) {
		this.new_flight_time = new_flight_time;
	}
	public int getFlight_duration() {
		return flight_duration;
	}
	public boolean isGo() {
		return go;
	}
	public void setGo(boolean go) {
		this.go = go;
	}
	public void setFlight_duration(int flight_duration) {
		this.flight_duration = flight_duration;
	}
	private void setCords() {
		for(Airport ard:owner.getAirports()) {
			if(start_Airport.equals(ard.getName())) {
				this.start_x=ard.getX();
				this.start_y=ard.getY();
			}
			if(end_Airport.equals(ard.getName())) {
				this.end_x=ard.getX();
				this.end_y=ard.getY();
			}
		}
	}
	public int getStart_x() {
		return start_x;
	}
	public void setStart_x(int start_x) {
		this.start_x = start_x;
	}
	public int getStart_y() {
		return start_y;
	}
	public void setStart_y(int start_y) {
		this.start_y = start_y;
	}
	public int getEnd_x() {
		return end_x;
	}
	public void setEnd_x(int end_x) {
		this.end_x = end_x;
	}
	public int getEnd_y() {
		return end_y;
	}
	public void setEnd_y(int end_y) {
		this.end_y = end_y;
	}
	public void setArrivalTime(int arrival) {
		this.arrival_time=arrival;
	}
	public int getArrivalTime() {
		return this.arrival_time;
	}
	
	
}
