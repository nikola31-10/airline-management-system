package FazaB;

import java.awt.Button;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Dialogs {

	

    // Funkcija koja pravi mali prozor sa porukom
    public static void showError(AirportMap parent, String message) {
        Dialog d = new Dialog(parent, "Greška", false); // modalni dijalog
        d.setLayout(new FlowLayout());

        Label l = new Label(message);
        Button ok = new Button("OK");

        ok.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                d.setVisible(false);
                d.dispose();
            }
        });

        d.add(l);
        d.add(ok);
        d.setSize(300, 100);
        d.setLocationRelativeTo(parent); // centrira dijalog
        d.setVisible(true);
    }
    public static void showOption(AirportMap parent, String message,Timer timer) {
        Dialog d = new Dialog(parent, "Ostalo vam je jos 5 sekundi", false); // modalni dijalog
        d.setLayout(new FlowLayout());

        Label l = new Label(message);
        Button ok = new Button("Da");

        if(timer.getSecondsPassed()==10) {
        	d.setVisible(false);
            d.dispose();
        }
        ok.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                d.setVisible(false);
                d.dispose();
            	parent.getTimer().resetSecondsPassed();
            	//parent.dispose();
            	
            }
        });

        d.add(l);
        d.add(ok);
        d.setSize(300, 100);
        d.setLocationRelativeTo(parent); // centrira dijalog
        d.setVisible(true);
        // Auto-close posle 5 sekundi
        new Thread(() -> {
            try {
                Thread.sleep(5000);
            } catch (InterruptedException ex) {}
            if (d.isVisible()) {
                d.setVisible(false);
                d.dispose();
                timer.stopTimer();
                parent.stopTimers();
                parent.dispose();
                parent.stopTimers();
                parent.getSceneWindow().dispose();
            }
        }).start();
    }
}
