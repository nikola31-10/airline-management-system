package FazaB;

public class SameNameException extends Exception {

	private String code;
    public SameNameException(String code) {
        super("Greska vec psostoji Aerodrom sa ovakvim nazivom: " + code);
        this.code = code;
    }
    public String getCode() {
        return code;
    }
}
