package FazaB;

import java.awt.*;
import java.util.*;
import java.util.List;

public class AirportMap extends Frame {

    // Polja
    Scene scene = new Scene(this);
    SceneWindow sceneWindow = new SceneWindow(this);

    private Panel eastPanel = new Panel();
    private Panel eastPanelLetovi = new Panel();

    private TextField xField = new TextField(5);
    private TextField yField = new TextField(5);
    private TextField codeField = new TextField(3);
    private TextField startAp = new TextField(3);
    private TextField endAp = new TextField(3);
    private TextField flightTm = new TextField(5);
    private TextField flightDu = new TextField(5);
    private TextField filename = new TextField(10);
    private TextField filenameLet = new TextField(10);

    private Label timerLabel = new Label("Time: 0");
    private Label timerSimLabel = new Label("TimeSim: 00:00");
    

    private Button unesi = new Button("Unesi aerodrom");
    private Button unesiFl = new Button("Unesi let");
    private Button simulation = new Button("Simulacija");
    private Button procitajAirport = new Button("Procitaj Aerodrome iz fajla");
    private Button procitajLetove = new Button("Procitaj Letove iz fajla");
    private Button stopSim = new Button("Pauziraj simulaciju");
    private Button continueSim = new Button("Nastavi simulaciju");
    private Button resetSim = new Button("Pokreni simulaciju od pocetka");

    
    
    private List<Airport> airports = new ArrayList<>();
    private Map<String, Checkbox> mapa = new HashMap<>();
    private List<Checkbox> boxovi = new ArrayList<>();

    
    private Timer timer;
    private TimerRepaint timerepaint;
    private TimerSimulation timer_sim;

    // Konstruktor 
    public AirportMap() {
        setTitle("Airport Map");
        //setBounds(100, 100, 1000, 800);
        setBounds(100, 100, 800, 600);
        setResizable(true);

        initTimers();
        layoutGUI();
        attachListeners();

        setVisible(true);
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                dispose();
                stopTimers();
                sceneWindow.dispose();
            }
        });
    }

    // Inicijalizacija tajmera
    private void initTimers() {
        timer = new Timer(timerLabel, scene, this);
        timerepaint = new TimerRepaint(scene);
        timer_sim = new TimerSimulation(timerSimLabel, scene);
        timer.start();
    }
    // Getter za tajmere
    public Timer getTimer() {
    	return timer;
    }
    public TimerSimulation getTimerSim() {
    	return timer_sim;
    }
    public TimerRepaint getTimerRepaint() {
    	return timerepaint;
    }
    // Stop timera
    public void stopTimers() {
    	if(timer.isStarted()) {
    		timer.stopTimer();
    	}
		if(timer_sim.isStarted()) {
			timer_sim.stopTimer();	
		}
		if(timerepaint.isStarted()) {
			timerepaint.stopTimer();
		}
		
    	
    }
    

    //  GUI layout 
    private void layoutGUI() {
        setLayout(new BorderLayout(10, 10));

        //  CENTER PANEL (input paneli) 
        Panel centerPanel = new Panel(new GridLayout(3, 1, 0, 10));
        centerPanel.add(createAirportInputPanel());
        centerPanel.add(createFlightInputPanel());
        centerPanel.add(createSimulationPanel());
        add(centerPanel, BorderLayout.CENTER);

        //  EAST PANEL (aerodromi i letovi) 
        Panel eastContainer = new Panel(new BorderLayout(0, 10));

        eastPanel.setLayout(new GridLayout(0, 1, 0, 2));
        ScrollPane eastScroll = new ScrollPane(ScrollPane.SCROLLBARS_AS_NEEDED);
        eastScroll.add(eastPanel);
        eastScroll.setPreferredSize(new Dimension(200, 300));
        eastContainer.add(eastScroll, BorderLayout.NORTH);

        eastPanelLetovi.setLayout(new GridLayout(0, 4, 2, 2));
        ScrollPane eastScrollLetovi = new ScrollPane(ScrollPane.SCROLLBARS_AS_NEEDED);
        eastScrollLetovi.add(eastPanelLetovi);
        eastScrollLetovi.setPreferredSize(new Dimension(200, 300));
        eastContainer.add(eastScrollLetovi, BorderLayout.CENTER);

        add(eastContainer, BorderLayout.EAST);
    }

    private Panel createAirportInputPanel() {
        Panel p = new Panel(new GridBagLayout());
        //p.setBackground(new Color(220, 220, 220)); // svetlo siva
        p.setBackground(Color.LIGHT_GRAY);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(2,2,2,2); // razmak oko komponenti
        gbc.anchor = GridBagConstraints.WEST;

        // Prvi red: X, Y, Code
        gbc.gridx = 0; gbc.gridy = 0; p.add(new Label("X:"), gbc);
        gbc.gridx = 1; p.add(xField, gbc);
        gbc.gridx = 2; p.add(new Label("Y:"), gbc);
        gbc.gridx = 3; p.add(yField, gbc);
        gbc.gridx = 4; p.add(new Label("Code:"), gbc);
        gbc.gridx = 5; p.add(codeField, gbc);
        gbc.gridx = 6; p.add(unesi, gbc);

        // Drugi red: fajl aerodroma
        gbc.gridx = 0; gbc.gridy = 1; p.add(new Label("Fajl aerodroma:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 2; p.add(filename, gbc);
        gbc.gridx = 3; gbc.gridwidth = 1; p.add(procitajAirport, gbc);

        // Treći red: fajl letova
        //gbc.gridx = 0; gbc.gridy = 2; p.add(new Label("Fajl letova:"), gbc);
        //gbc.gridx = 1; gbc.gridwidth = 2; p.add(filenameLet, gbc);
        //gbc.gridx = 3; gbc.gridwidth = 1; p.add(procitajLetove, gbc);

        return p;
    }

    private Panel createFlightInputPanel() {
        Panel p = new Panel(new GridBagLayout());
        //p.setBackground(new Color(200, 230, 255)); // svetlo plava
        p.setBackground(Color.PINK);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        // Prvi red: Start i End airport
        gbc.gridx = 0; gbc.gridy = 0; p.add(new Label("Start airport:"), gbc);
        gbc.gridx = 1; p.add(startAp, gbc);
        gbc.gridx = 2; p.add(new Label("End airport:"), gbc);
        gbc.gridx = 3; p.add(endAp, gbc);

        // Drugi red: Flight time i duration
        gbc.gridx = 0; gbc.gridy = 1; p.add(new Label("Flight time:"), gbc);
        gbc.gridx = 1; p.add(flightTm, gbc);
        gbc.gridx = 2; p.add(new Label("Duration:"), gbc);
        gbc.gridx = 3; p.add(flightDu, gbc);

        // Treći red: dugme
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 1; p.add(unesiFl, gbc);
        //Cetvrti red:
        gbc.gridx = 0; gbc.gridy = 3; p.add(new Label("Fajl letova:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 2; p.add(filenameLet, gbc);
        gbc.gridx = 3; gbc.gridwidth = 1; p.add(procitajLetove, gbc);
        
        
        /*gbc.gridx=0;gbc.gridy=4;p.add(upisiUfajl,gbc);
        upisiUfajl.addActionListener(
        e -> {
        	WriteInFIle.upisiUFajl(filename.getText(), "Prva linija");
            timer.resetSecondsPassed();
        });*/

        

        return p;
    }

    private Panel createSimulationPanel() {
        Panel p = new Panel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        //p.setBackground(new Color(255, 220, 180)); // svetlo narandžasta
        p.add(timerLabel); p.add(timerSimLabel);
        p.setBackground(Color.YELLOW);
        timerLabel.setVisible(false);
        p.add(simulation); p.add(stopSim); p.add(continueSim); p.add(resetSim);
        return p;
    }


    //  Listeneri 
    private void attachListeners() {
        unesi.addActionListener(e -> dugmeZaDodavanjeAirport(xField.getText(), yField.getText(), codeField.getText()));
        unesiFl.addActionListener(e -> dugmeFl(startAp.getText(), endAp.getText(), flightDu.getText(), flightTm.getText()));
        simulation.addActionListener(e -> {
        	if(scene.getSimulation()) {
        		return;
        	}
        	timer.pauseTimer();
        	timer.resetSecondsPassed();
            scene.setSimulation(true);
            if(!timerepaint.isStarted()) {
            	timerepaint.start();
            }
            if(!timer_sim.isStarted()) {
            	timer_sim.start();
            }
            else {
            	timer_sim.continueTimer();
            }
            
            //timer_sim.start();
            
            scene.repaint();
        });
        procitajAirport.addActionListener(e -> {
            new ReadAirportFromFile(filename.getText(), this).ucitaj();
            timer.resetSecondsPassed();
        });
        procitajLetove.addActionListener(e -> {
            new ReadFlightFromFile(filenameLet.getText(), this).ucitaj();
            timer.resetSecondsPassed();
        });
        stopSim.addActionListener(e -> timer_sim.pauseTimer());
        continueSim.addActionListener(e -> timer_sim.continueTimer());
        resetSim.addActionListener(e -> timer_sim.resetSecondsPassed());
    }

    //  Logika aerodroma 
    public void dugmeZaDodavanjeAirport(String x, String y, String code) {
        timer.resetSecondsPassed();
        try {
            int xi = Integer.parseInt(x);
            int yi = Integer.parseInt(y);

            if (sameAirportName(code) || wrongAirportName(code) || wrongCoords(xi, yi) || takenCoords(xi, yi)) {
                throw new Exception("Neispravni podaci");
            }

            Checkbox cb = new Checkbox(code + " X=" + x + " Y=" + y);
            eastPanel.add(cb); boxovi.add(cb); mapa.put(code, cb);
            
            cb.addItemListener(ev -> scene.repaint());

            airports.add(new Airport(xi, yi, code));

            eastPanel.revalidate(); eastPanel.repaint();
            xField.setText(""); yField.setText(""); codeField.setText("");
            scene.repaint();
        } catch (Exception ex) {
            Dialogs.showError(this, "Proverite podatke");
        }
    }

    //  Logika letova 
    public void dugmeFl(String pocetni, String krajnji, String trjanje, String poletanje) {
    	if(scene.getSimulation()) {
    		return;
    	}
        timer.resetSecondsPassed();
        if (!sameAirportName(pocetni) || !sameAirportName(krajnji) || !validStartTime(poletanje)) {
            Dialogs.showError(this, "Proverite podatke za let");
            return;
        }

        String poletanjePom = poletanje;
        boolean same;
        for (Airport ard : airports) {
            if (ard.getName().equals(pocetni)) {
                same = true;
                while (same) {
                    same = false;
                    for (Flight let : ard.getFlights()) {
                        if (Math.abs(startTimeToInt(let.getFlight_time()) - startTimeToInt(poletanjePom)) < 10) {
                            poletanjePom = plus10(let.getFlight_time());
                            same = true;
                            break;
                        }
                    }
                }
            }
        }

        Flight let = new Flight(pocetni, krajnji, poletanjePom, Integer.parseInt(trjanje), this);

        let.setArrivalTime(startTimeToInt(poletanjePom)+Integer.parseInt(trjanje));
        eastPanelLetovi.add(new Label(pocetni));
        eastPanelLetovi.add(new Label(krajnji));
        eastPanelLetovi.add(new Label(trjanje));
        eastPanelLetovi.add(new Label(poletanjePom));

        eastPanelLetovi.revalidate();
        eastPanelLetovi.repaint();

        for (Airport ard : airports) {
            if (ard.getName().equals(let.getStart_Airport())) {
                ard.getFlights().add(let);
            }
        }

        startAp.setText(""); endAp.setText(""); flightDu.setText(""); flightTm.setText("");
    }

    //  Helper metode 
    public boolean sameAirportName(String name) {
        return airports.stream().anyMatch(a -> a.getName().equals(name));
    }
    public boolean wrongAirportName(String name) {
        return !name.matches("[A-Z]{3}");
    }
    public boolean wrongCoords(int x, int y) {
        return x < -90 || x > 90 || y < -90 || y > 90;
    }
    public boolean takenCoords(int x, int y) {
        return airports.stream().anyMatch(a -> a.getX() == x && a.getY() == y);
    }

    public String plus10(String poletanje) {
        String[] parts = poletanje.split(":");
        int sati = Integer.parseInt(parts[0]);
        int minuti = Integer.parseInt(parts[1]) + 10;
        if (minuti >= 60) { sati++; minuti -= 60; }
        return String.format("%02d:%02d", sati, minuti);
    }

    public int startTimeToInt(String poletanje) {
        String[] parts = poletanje.split(":");
        return Integer.parseInt(parts[0]) * 60 + Integer.parseInt(parts[1]);
    }

    public boolean validStartTime(String time) {
        return time.matches("([01]\\d|2[0-3]):[0-5]\\d");
    }
    
    

    // Getteri i setteri za vazna polja
    public List<Airport> getAirports() {
		return airports;
	}

	public void setAirports(List<Airport> airports) {
		this.airports = airports;
	}

	public Map<String, Checkbox> getMapa() {
		return mapa;
	}

	public void setMapa(Map<String, Checkbox> mapa) {
		this.mapa = mapa;
	}

	public List<Checkbox> getBoxovi() {
		return boxovi;
	}

	public void setBoxovi(List<Checkbox> boxovi) {
		this.boxovi = boxovi;
	}
	public SceneWindow getSceneWindow() {
		return this.sceneWindow;
	}
	
	

	//   Main 
    public static void main(String[] args) {
        new AirportMap();
    }
}
//text fajlovi van src