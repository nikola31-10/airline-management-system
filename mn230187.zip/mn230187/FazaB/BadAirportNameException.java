package FazaB;

public class BadAirportNameException extends Exception {

	private String code;
    public BadAirportNameException(String code) {
        super("Greska, Aerodrom treba da se sastoji od 3 velika slova: " + code);
        this.code = code;
    }
   
	public String getCode() {
        return code;
    }
}
