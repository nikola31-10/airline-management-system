package FazaB;

public class BadCoordsException extends Exception {
	//private String code;
    public BadCoordsException(int xkor,int ykor) {
        super("Koordinate nisu odgovarajuce");
        
    }
   
}
